#!/usr/bin/python
import sys
def lineorder(line):
   lo_orderdate=line[5]
   lo_partkey=line[3]
   try:
      lo_revenue=line[12]
   except :
      print(line)
   print '%s\t%s\t%s' % (lo_orderdate,lo_partkey,lo_revenue)     
        
def dwdate(line):
   d_datekey=line[0]
   d_sellingseason=line[12]
   d_year=line[4]
   if d_sellingseason=='Fall':
      print '%s\t%s\t%s\t%s' % (d_datekey,"","",d_year)     
   
def part(line):
   p_partkey=line[0]
   p_brand1=line[4]
   if p_brand1 >='MFGR#2121' and p_brand1 <= 'MFGR#2138':
      print '%s\t%s\t%s\t%s\t%s' % ("",p_partkey,"","",p_brand1)
   
for line in sys.stdin:
   line = line.strip()
   line = line.split('|')
   #print(len(line),line)
   if len(line)==10:
        part(line)
   elif len(line[0])==8:
        dwdate(line)
   else:
        lineorder(line)

