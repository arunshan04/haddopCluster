#!/usr/bin/python
import sys
def lineorderdate(line):
   lo_orderdate=line[0]
   lo_partkey=line[1]
   lo_revenue=line[2]
   d_year=line[3]
   print '%s\t%s\t%s' % (lo_partkey,lo_revenue,d_year)     
   
def part(line):
   p_partkey=line[0]
   p_brand1=line[4]
   if p_brand1 >='MFGR#2121' and p_brand1 <= 'MFGR#2138':
      print '%s\t%s\t%s\t%s' % (p_partkey,"","",p_brand1)
   
for line in sys.stdin:
   line = line.strip()
   line = line.split('|')
   #print(len(line),line)
   if len(line)==10:
        part(line)
   else:
        lineorderdate(line)

