#!/usr/bin/python
import sys
prev_lo_orderdate=None
prev_lname=None
lineorder=[]
dwdate=[]
for line in sys.stdin:
   line = line.strip()
   line = line.split('\t')
   lo_orderdate=line[0]
   #print('****',prev_lo_orderdate,lo_orderdate)
   if ( lo_orderdate != prev_lo_orderdate ) and ( prev_lo_orderdate != None  ):
        for i in lineorder:
            #print('****',lineorder,dwdate)
            for j in dwdate:
                print '%s|%s|%s|%s' % (i[0],i[1],i[2],j[3])
        lineorder=[]
        dwdate=[]
        if len(line)==3:
            lineorder.append(line)
        else:
            dwdate.append(line)
   else:
#        print('matching')
        if len(line)==3:
            lineorder.append(line)
        else:
            dwdate.append(line)
   prev_lo_orderdate=lo_orderdate

