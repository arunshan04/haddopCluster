#!/usr/bin/python
import sys
prev_d_datekey=None
prev_lname=None
lineorder=[]
dwdate=[]
pgroup=pyear=None
lst=[]
for line in sys.stdin:
   line = line.strip()
   line = line.split('\t')
   d_datekey=line[0]
   #print('****',prev_d_datekey,d_datekey)
   if ( d_datekey != prev_d_datekey ) and ( prev_d_datekey != None  ):
        for i in lineorder:
            for j in dwdate:
               print '%s\t%s\t%s' % (i[2],j[3],i[1])
        lineorder=[]
        dwdate=[]
        if len(line)==3:
            lineorder.append(line)
        else:
            dwdate.append(line)
   else:
#        print('matching')
        if len(line)==3:
            lineorder.append(line)
        else:
            dwdate.append(line)
   prev_d_datekey=d_datekey

