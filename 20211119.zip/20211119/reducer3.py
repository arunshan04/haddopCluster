#!/usr/bin/python
import sys
prev_d_year=None
prev_lname=None
lineorder=[]
dwdate=[]
pgroup=None

lst=[]
for line in sys.stdin:
   line = line.strip()
   line = line.split('\t')
   d_year=line[0]
   group=line[1]
   lo_revenue=int(line[2])
   #print('****',prev_d_year,d_year)
   #print(d_year,group,prev_d_year,pgroup,lst)
   if ( d_year != prev_d_year or group != pgroup ) and pgroup !=None: 
       print '%s\t%s\t%s' % (prev_d_year,pgroup,sum(lst))
       lst=[]
       lst.append(lo_revenue)
   else:
       lst.append(lo_revenue)
   prev_d_year=d_year
   pgroup=group
   #print '%s\t%s\t%s' % (prev_d_year,pgroup,lst)
print '%s\t%s\t%s' % (prev_d_year,pgroup,sum(lst))

